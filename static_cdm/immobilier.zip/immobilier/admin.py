
from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Departement)
admin.site.register(Commune)
admin.site.register(Arrondissement)
admin.site.register(Quartier)
admin.site.register(Operation)
admin.site.register(Types)
admin.site.register(Immeuble)
admin.site.register(Chambre)
admin.site.register(Salon)
admin.site.register(Cuisine)
admin.site.register(Douche)
admin.site.register(Balcon)
admin.site.register(Chambres)
admin.site.register(ImagesImmeuble)
admin.site.register(Images)
admin.site.register(Terrain)
admin.site.register(ImagesPlan)
admin.site.register(Offre)
admin.site.register(ContactezNous)
admin.site.register(Annonce)
